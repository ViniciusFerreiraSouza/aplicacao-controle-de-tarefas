namespace aplicacao_controle_de_tarefas.Models
{
    public class Kestrel
    {
        "Kestrel": {
            "EndPoints": {
            "Http1": { "Url": "http://localhost:5000" }
            }
        }
    }
}